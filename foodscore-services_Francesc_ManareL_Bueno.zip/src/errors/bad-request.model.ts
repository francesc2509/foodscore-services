export class BadRequest extends Error {}
