export class TokenRequest {
  token: string;
  lat?: number;
  lng?: number;
}
