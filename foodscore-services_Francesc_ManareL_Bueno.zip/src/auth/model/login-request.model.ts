export interface LoginRequest {
  email: string;
  password: string;
  lat?: number;
  lng?: number;
}
