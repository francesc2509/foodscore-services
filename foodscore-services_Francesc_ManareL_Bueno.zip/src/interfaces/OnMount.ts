export interface OnMount {
  fsOnMount(): void;
}
